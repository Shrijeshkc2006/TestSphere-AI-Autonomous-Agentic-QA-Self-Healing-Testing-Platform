import react from 'react';

const First = () => {
    return (
        <div>
            <h1>First Component</h1>
        </div>
    );
}

export default First;