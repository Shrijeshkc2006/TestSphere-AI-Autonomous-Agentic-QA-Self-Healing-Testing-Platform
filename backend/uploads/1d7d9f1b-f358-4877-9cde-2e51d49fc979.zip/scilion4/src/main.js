// ============================================================
// SCILION WEBSITE — Main JavaScript
// ============================================================

// ——— INIT ——————————————————————————————————————————————————

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initMobileMenu();
  initRevealAnimations();
  initServiceAccordion();
  initContactModal();
  initContactForm();
  initSmoothScroll();
  initParallax();
  initMarquee();
  initHeroCanvas();
});

// ——— NAVIGATION ————————————————————————————————————————————

function initNavigation() {
  const nav = document.getElementById('nav');
  let lastScroll = 0;
  let ticking = false;

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const currentScroll = window.scrollY;
        if (currentScroll > 40) {
          nav.classList.add('scrolled');
        } else {
          nav.classList.remove('scrolled');
        }
        lastScroll = currentScroll;
        ticking = false;
      });
      ticking = true;
    }
  });

  // Nav link active states
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }, { threshold: 0.3 });

  sections.forEach(s => observer.observe(s));
}

// ——— MOBILE MENU ———————————————————————————————————————————

function initMobileMenu() {
  const btn = document.getElementById('navMenuBtn');
  const menu = document.getElementById('mobileMenu');
  const closeLinks = document.querySelectorAll('[data-close]');

  function openMenu() {
    menu.classList.add('open');
    btn.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    menu.classList.remove('open');
    btn.classList.remove('active');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', () => {
    if (menu.classList.contains('open')) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  closeLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeMenu();
    });
  });

  // Close on overlay tap
  menu.addEventListener('click', (e) => {
    if (e.target === menu) closeMenu();
  });
}

// ——— REVEAL ANIMATIONS ————————————————————————————————————

function initRevealAnimations() {
  const elements = document.querySelectorAll('.reveal-up');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -60px 0px'
  });

  elements.forEach(el => observer.observe(el));
}

// ——— SERVICE ACCORDION ————————————————————————————————————

function initServiceAccordion() {
  const items = document.querySelectorAll('.service-item');

  items.forEach(item => {
    const top = item.querySelector('.service-top');

    top.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');

      // Close all
      items.forEach(i => i.classList.remove('open'));

      // Open clicked if not open
      if (!isOpen) {
        item.classList.add('open');
      }
    });
  });

  // Open first item by default
  if (items.length > 0) {
    items[0].classList.add('open');
  }
}

// ——— CONTACT MODAL ————————————————————————————————————————

function initContactModal() {
  const modal = document.getElementById('contactModal');
  const overlay = document.getElementById('modalOverlay');
  const closeBtn = document.getElementById('closeModal');
  const openBtns = [
    document.getElementById('openContactForm'),
    document.getElementById('heroCtaPrimary'),
    document.getElementById('navCta'),
    document.querySelector('.mobile-cta'),
  ].filter(Boolean);

  function openModal() {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }

  openBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal();
    });
  });

  closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', closeModal);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeModal();
    }
  });
}

// ——— CONTACT FORM (WEB3FORMS) —————————————————————————————

function initContactForm() {
  const form = document.getElementById('contactForm');
  const submitBtn = document.getElementById('formSubmitBtn');
  const submitText = document.querySelector('.form-submit-text');
  const submitLoading = document.querySelector('.form-submit-loading');
  const successDiv = document.getElementById('formSuccess');
  const errorBanner = document.getElementById('formErrorBanner');
  const accessKeyInput = document.getElementById('accessKey');

  // Set access key from env variable
  const accessKey = import.meta.env.VITE_WEB3FORMS_ACCESS_KEY || '';
  if (accessKeyInput) {
    accessKeyInput.value = accessKey;
  }

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Clear previous errors
    clearErrors();

    // Validate
    let isValid = true;

    const name = document.getElementById('formName');
    const email = document.getElementById('formEmail');
    const projectType = document.getElementById('formProjectType');
    const message = document.getElementById('formMessage');

    if (!name.value.trim()) {
      showError('nameError', 'Please enter your name');
      isValid = false;
    }

    if (!email.value.trim() || !isValidEmail(email.value)) {
      showError('emailError', 'Please enter a valid email address');
      isValid = false;
    }

    if (!projectType.value) {
      showError('projectError', 'Please select a project type');
      isValid = false;
    }

    if (!message.value.trim() || message.value.trim().length < 20) {
      showError('messageError', 'Please describe your project (at least 20 characters)');
      isValid = false;
    }

    if (!isValid) return;

    // Loading state
    setLoading(true);

    try {
      const formData = new FormData(form);
      const object = Object.fromEntries(formData);
      const json = JSON.stringify(object);

      const res = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: json
      });

      const result = await res.json();

      if (result.success) {
        // Show success
        form.style.display = 'none';
        successDiv.style.display = 'flex';
      } else {
        throw new Error(result.message || 'Submission failed');
      }

    } catch (err) {
      console.error('Form error:', err);
      errorBanner.style.display = 'block';
      setLoading(false);
    }
  });

  function setLoading(loading) {
    if (loading) {
      submitBtn.disabled = true;
      submitText.style.display = 'none';
      submitLoading.style.display = 'block';
    } else {
      submitBtn.disabled = false;
      submitText.style.display = 'block';
      submitLoading.style.display = 'none';
    }
  }

  function showError(id, msg) {
    const el = document.getElementById(id);
    if (el) el.textContent = msg;
  }

  function clearErrors() {
    document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
    errorBanner.style.display = 'none';
  }

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
}

// ——— SMOOTH SCROLL ————————————————————————————————————————

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href === '#' || href === '#contact') return; // contact handled by modal

      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const navH = 72;
        const top = target.getBoundingClientRect().top + window.scrollY - navH;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });
}

// ——— PARALLAX ————————————————————————————————————————————

function initParallax() {
  let ticking = false;

  const heroVisual = document.querySelector('.hero-visual');

  function handleParallax() {
    if (!ticking) {
      requestAnimationFrame(() => {
        const scrollY = window.scrollY;

        if (heroVisual) {
          heroVisual.style.transform = `translateY(${scrollY * 0.1}px)`;
        }

        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener('scroll', handleParallax, { passive: true });
}

// ——— MARQUEE ————————————————————————————————————————————

function initMarquee() {
  // Pause marquee on hover
  const marqueeInner = document.getElementById('marqueeInner');
  if (!marqueeInner) return;

  const parent = marqueeInner.parentElement;
  parent.addEventListener('mouseenter', () => {
    marqueeInner.style.animationPlayState = 'paused';
  });
  parent.addEventListener('mouseleave', () => {
    marqueeInner.style.animationPlayState = 'running';
  });
}

// ——— HERO CANVAS ————————————————————————————————————————

function initHeroCanvas() {
  const canvas = document.getElementById('heroCanvas');
  if (!canvas) return;

  // Mouse parallax on hero visual
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = (e.clientX - cx) / rect.width;
    const dy = (e.clientY - cy) / rect.height;

    const pills = canvas.querySelectorAll('.hc-pill');
    const orbs = canvas.querySelectorAll('.hc-orb');

    pills.forEach((pill, i) => {
      const factor = (i + 1) * 8;
      pill.style.transform = `translate(${dx * factor}px, ${dy * factor}px)`;
    });

    orbs.forEach((orb, i) => {
      const factor = (i + 1) * 12;
      orb.style.transform = `translate(${dx * factor}px, ${dy * factor}px)`;
    });
  });

  canvas.addEventListener('mouseleave', () => {
    const pills = canvas.querySelectorAll('.hc-pill');
    const orbs = canvas.querySelectorAll('.hc-orb');
    pills.forEach(p => p.style.transform = '');
    orbs.forEach(o => o.style.transform = '');
  });
}

// ——— STAT COUNTER ANIMATION —————————————————————————————

function initStatCounters() {
  const stats = document.querySelectorAll('.stat-number');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const suffix = el.querySelector('.stat-suffix');
        const suffixText = suffix ? suffix.outerHTML : '';
        const target = parseInt(el.textContent.replace('+', '').replace(/\D/g, ''));

        let current = 0;
        const duration = 1200;
        const step = duration / 60;
        const increment = target / 60;

        const timer = setInterval(() => {
          current = Math.min(current + increment, target);
          el.innerHTML = Math.floor(current) + suffixText;
          if (current >= target) {
            clearInterval(timer);
          }
        }, step);

        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  stats.forEach(stat => observer.observe(stat));
}

document.addEventListener('DOMContentLoaded', initStatCounters);
